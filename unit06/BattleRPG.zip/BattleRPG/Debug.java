// Implement `Display` if you would like to print an object's state for easy debugging
interface Debug {
  public void debug();
}
